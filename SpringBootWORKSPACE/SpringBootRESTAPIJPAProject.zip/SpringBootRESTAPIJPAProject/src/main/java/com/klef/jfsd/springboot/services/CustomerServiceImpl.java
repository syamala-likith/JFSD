package com.klef.jfsd.springboot.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService
{
	@Autowired
	public CustomerRepository repository;
	

	@Override
	public String addcustomer(Customer customer) 
	{
		repository.save(customer);
		
		return "Customer Added Successfully";
	}

	@Override
	public String updatecustomer(Customer customer) 
	{
		Customer c = repository.findById(customer.getId()).get();
		
		c.setName(customer.getName());
		c.setSalary(customer.getSalary());
		
		repository.save(c);
		
		return "Customer Updated Successfully";
	}

	@Override
	public String deletecustomer(int id) 
	{
		Customer c = repository.findById(id).get();
		repository.delete(c);
		return "Customer Deleted Successfully";
	}

	@Override
	public List<Customer> viewallcustomers() 
	{
		List<Customer> customerlist = (List<Customer>)repository.findAll();
		return customerlist;
	}

	@Override
	public Customer viewcustomerbyid(int id) 
	{
		Customer c = repository.findById(id).get();
		return c;
		
	}

}
